function idOpensell()
{
	var myDiv = document.getElementById("request");
    myDiv.style.display = "flex";
}
function idClosessell()
{
	var myDiv = document.getElementById("request");
    myDiv.style.display = "none";
}
function idOpen()
{
	var myDiv = document.getElementById("login");
    myDiv.style.display = "flex";
}
function idClose()
{
	var myDiv = document.getElementById("login");
    myDiv.style.display = "none";
}
function idOpens()
{
	var myDiv = document.getElementById("signup");
    myDiv.style.display = "flex";
}
function idCloses()
{
	var myDiv = document.getElementById("signup");
    myDiv.style.display = "none";
}

/* Устанавливаем стартовый индекс слайда по умолчанию: */
let slideIndex = 1;
/* Вызываем функцию, которая реализована ниже: */
showSlides(slideIndex);

/* Увеличиваем индекс на 1 — показываем следующий слайд: */
function nextSlide() {
    showSlides(slideIndex += 1);
}

/* Уменьшаем индекс на 1 — показываем предыдущий слайд: */
function previousSlide() {
    showSlides(slideIndex -= 1);
}

/* Устанавливаем текущий слайд: */
function currentSlide(n) {
    showSlides(slideIndex = n);
}

/* Функция перелистывания: */
function showSlides(n) {
    /* Обращаемся к элементам с названием класса "item", то есть к картинкам: */
    let slides = document.getElementsByClassName("item");

    /* Проверяем количество слайдов: */
    if (n > slides.length) {
      slideIndex = 1
    }
    if (n < 1) {
        slideIndex = slides.length
    }

    /* Проходим по каждому слайду в цикле for: */
    for (let slide of slides) {
        slide.style.display = "none";
    }
    /* Делаем элемент блочным: */
    slides[slideIndex - 1].style.display = "block";
}

sel.onchange= e=>alert(e.target.value);

// Для перехода на нужную страницу вписываете в обработчик:
// location.href= 'адрес вашей страницы';

$(".favoriteBut").on("click", function() {
    $(this).addClass("active")
    $(this).find(".scattering").addClass("active")
})