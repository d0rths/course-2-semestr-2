const { spawn } = require('child_process');

// Путь к исполняемому файлу node
const nodePath = 'node';

// Путь к скрипту для запуска
const scriptPath = 'server.js';

// Аргументы для передачи скрипту (если необходимо)
const args = [];

// Опции для запуска процесса
const options = {
  stdio: 'inherit' // Выводить стандартный вывод в терминал
};

// Запуск процесса
const serverProcess = spawn(nodePath, [scriptPath, ...args], options);

// Обработка ошибок
serverProcess.on('error', (err) => {
  console.error('Server process failed to start: ', err);
});

// Обработка завершения процесса
serverProcess.on('exit', (code, signal) => {
  console.log(`Server process exited with code ${code} and signal ${signal}`);
});
