const http = require('http');
const fs = require('fs');
const path = require('path');

const express = require('express');
const Firebird = require('node-firebird');
const app = express();  

const options = {
  host: 'localhost',
  port: 3050,
  database: 'C:/Users/rusla/Desktop/site/DATABASE.FDB',
  user: 'SYSDBA',
  password: 'masterkey',
   lowercase_keys: false // Для сохранения регистра полей
};



app.post('/addUser', (req, res) => {
  const { id, name, email, password } = req.body;

  // Подключение к базе данных Firebird
  firebird.attach(options, (err, db) => {
    if (err) {
      console.error(err.message);
      res.status(500).json({ error: 'Ошибка подключения к базе данных' });
      return;
    }

    // Выполнение запроса на добавление пользователя
    const sql = `INSERT INTO USERS (ID, NAME, EMAIL, PASSWORD) VALUES (?, ?, ?, ?)`;
    const params = [id, name, email, password];

    db.query(sql, params, (err, result) => {
      if (err) {
        console.error(err.message);
        res.status(500).json({ error: 'Ошибка выполнения запроса' });
      } else {
        console.log('Пользователь успешно добавлен');
        res.json({ success: true });
      }

      // Закрытие соединения с базой данных
      db.detach();
    });
  });
});

const server = http.createServer((req, res) => {
	

let filePath = path.join(__dirname, req.url);

  // check if the file exists, otherwise add the .html extension
  if (fs.existsSync(filePath)) {
    if (fs.lstatSync(filePath).isDirectory()) {
      filePath += '/index.html';
    }
  } else {
    filePath += '.html';
  }
  // read the file extension and set the appropriate content type
  const ext = path.extname(filePath);
  let contentType = '';

  switch (ext) {
    case '.html':
      contentType = 'text/html';
      break;
    case '.css':
      contentType = 'text/css';
      break;
    case '.js':
      contentType = 'text/javascript';
      break;
	  case '.fdb':
      contentType = 'application/octet-stream';
      break;
    default:
      contentType = 'text/plain';
      break;
  }

  // read the file and send it as the response
  fs.readFile(filePath, (err, content) => {
    if (err) {
      res.writeHead(404);
      res.write(`Error: ${err}`);
      res.end();
    } else {
      res.writeHead(200, { 'Content-Type': contentType });
      res.write(content);
      res.end();
    }
  });
  

});

server.listen(3050, () => {
  console.log('Server is listening on port 3050');
});


